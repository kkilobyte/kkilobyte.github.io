# Discord Mods
This is a repo where I upload addons to existing Discord client mods, such as Powercord, Vencord, and BetterDiscord

# Where is everything?
BetterDiscord plugins are in /bbd-plugins, BetterDiscord and Vencord themes are in /discord-themes, and so on.
